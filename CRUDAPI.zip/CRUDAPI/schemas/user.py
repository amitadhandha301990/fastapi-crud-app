from pydantic import Basemodel


class User(Basemodel):
    id:int
    name:str
    email:str
    password:str
