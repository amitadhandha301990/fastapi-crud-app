from pydantic import BaseModel
from sqlalchemy import create_engine,MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

engine= create_engine("mysql+pymysql://root@localhost:3306/user")
meta=MetaData()
conn=engine.connect()

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


BaseModel = declarative_base()

def get_db():
    db=SessionLocal()
    try:
        yield db
    finally:
        db.close()
            