from django.http import response
from fastapi import FastAPI, Request, Depends, Query
import json
from typing import Optional
from pydantic import BaseModel
from config.database import BaseModel,engine,SessionLocal
from models import user
from fastapi_pagination import Page, add_pagination, paginate
from sqlalchemy.orm import Session

BaseModel.metadata.create_all(bind=engine)


app = FastAPI()



with open('user.json') as f:
    User = json.load(f)


@app.get("/user",response_model=Page[User])
def read_user_list():
    return paginate(users) 

def search_user(query: str, database: Session):
    jobs = database.query(users).filter(users.title.contains(query))
    return jobs    


@app.get("/")
def index():
    return ""


@app.get("/user/get/{id}")
def read_user(id: int):
    
    return {f"read user id {id}"}


@app.post("/user")
def create_user():
    return "create user"


@app.put("/user/add/{id}")
def add_user(id: int):
    return "add user with id {id}"


@app.delete("/user/{id}")
def delete_user(id: int):
    return "delete user id with id {id}"
