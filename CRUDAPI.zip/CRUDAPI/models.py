from email.mime import image
from pydantic import BaseModel
from sqlalchemy import  Column, Integer, String
from sqlalchemy.orm import relationship
from sqlalchemy import Table,Column,Integer,String
from config.database import MetaData
from config.database import BaseModel



class User(BaseModel):
    __tablename__ = "user"

    id = Column(Integer, primary_key=True, index=True)
    name=Column(str(50))
    email = Column(String, unique=True, index=True)
    password=Column(String)
    phone_no=Column(int)
    address=Column(str)
    city=Column(str)
    state=Column(str)
    Country=Column(str)
    zip=Column(int)
    photo=Column(String)



